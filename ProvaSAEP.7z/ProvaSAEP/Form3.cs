﻿using ProvaSAEP.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProvaSAEP
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        public void CarregaDGV()
        {
            Cliente saldo = new Cliente();
            dgvCliente.DataSource = saldo.ListaClientes();
        }

        public void CarregaDGVCon()
        {
            Concessionarias saldo = new Concessionarias();
            dgvConcessionaria.DataSource = saldo.ListaConcessionarias();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            CarregaDGV();
            CarregaDGVCon();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtCliente.Text == "" || txtCon.Text == "")
            {
                MessageBox.Show("Para seguir é necessario preencher os campos");
            }
            else
            {
                MessageBox.Show("Venda Efetuada com sucesso!");

                Form3 fechar = new Form3();

                fechar.Close();

                txtCon.Text = "";
                txtCliente.Text = "";
            }
        }
    }
}
