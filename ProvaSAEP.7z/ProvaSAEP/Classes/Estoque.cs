﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProvaSAEP.Classes;

namespace ProvaSAEP.Classes
{
    class Estoque

    {

        public int id { get; set; }
        public int area { get; set; }
        public int automovel { get; set; }
        public int concessionaria { get; set; }
        public int quantidade { get; set; }

        public Estoque(int id, int area, int automovel, int concessionaria, int quantidade)
        {
            this.id = id;
            this.area = area;
            this.automovel = automovel;
            this.concessionaria = concessionaria;
            this.quantidade = quantidade;
        }

        public Estoque()
        {
        }

        public List<Estoque> ListaArea1()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 1";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea2()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 2";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea3()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 3";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea4()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 4";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea5()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 5";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea6()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 6";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea7()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 7";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea8()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 8";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea9()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 9";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea10()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 10";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

        public List<Estoque> ListaArea11()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Estoque> li = new List<Estoque>();
            string sql = "SELECT * FROM alocacao WHERE area = 11";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Estoque m = new Estoque();
                m.id = (int)dr["id"];
                m.area = (int)dr["area"];
                m.automovel = (int)dr["automovel"];
                m.concessionaria = (int)dr["concessionária"];
                m.quantidade = (int)dr["quantidade"];
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }


    }
}
