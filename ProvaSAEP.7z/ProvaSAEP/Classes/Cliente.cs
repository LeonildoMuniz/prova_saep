﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProvaSAEP.Classes;

namespace ProvaSAEP.Classes
{
    class Cliente
    {
        public int id { get; set; }
        public string nome { get; set; }

        public Cliente(int id, string nome)
        {
            this.id = id;
            this.nome = nome;

        }

        public Cliente()
        {

        }

        public List<Cliente> ListaClientes()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Cliente> li = new List<Cliente>();
            string sql = "SELECT * FROM clientes";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Cliente m = new Cliente();
                m.id = (int)dr["id"];
                m.nome = dr["nome"].ToString();
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }

    }
}
