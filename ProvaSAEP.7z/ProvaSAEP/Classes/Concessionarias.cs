﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProvaSAEP.Classes
{
    class Concessionarias
    {
        public int id { get; set; }
        public string concessionária { get; set; }

        public Concessionarias(int id, string nome)
        {
            this.id = id;
            this.concessionária = nome;

        }

        public Concessionarias()
        {

        }

        public List<Concessionarias> ListaConcessionarias()
        {
            SqlConnection con = ConBanco.ObterConexao();
            List<Concessionarias> li = new List<Concessionarias>();
            string sql = "SELECT * FROM concessionarias";
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Concessionarias m = new Concessionarias();
                m.id = (int)dr["id"];
                m.concessionária = dr["concessionária"].ToString();
                li.Add(m);
            }
            ConBanco.FecharConexao();
            dr.Close();
            return li;

        }
    }
}
